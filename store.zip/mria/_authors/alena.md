---
username: alena
name: Alena Curtis
image: '/images/01-1.jpg'
cover:
location: Mexico
website: https://www.google.com
twitter: https://twitter.com
facebook: https://www.facebook.com
---
I have experience in photographing beauty, fashion, e-commerce, and product photography for various brands.